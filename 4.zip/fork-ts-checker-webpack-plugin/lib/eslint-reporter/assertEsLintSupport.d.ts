import { EsLintReporterConfiguration } from './EsLintReporterConfiguration';
declare function assertEsLintSupport(configuration: EsLintReporterConfiguration): void;
export { assertEsLintSupport };
