import { Issue } from '../issue';
declare type Formatter = (issue: Issue) => string;
export { Formatter };
